#!/usr/bin/env bash
# Interactive launcher; accepts stage numbers for noninteractive execution too.
set -eo pipefail
DEMO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DEMO_ROOT
names=(naive preload_gamma multi_core vf double_buffer ub_utilization binary_sum)
descriptions=("Baseline implementation" "Preload gamma, single core" "Distribute rows across cores" "MicroAPI VF, single buffer" "MicroAPI VF, double buffer" "Batch rows in UB" "Binary sum and reciprocal square root")
list_variants() {
    printf '\nRMSNorm / BiProf — default shape 128 x 256\n\n'
    for i in 0 1 2 3 4 5 6; do
        printf '  %s  %-16s %s\n' "$i" "${names[$i]}" "${descriptions[$i]}"
    done
}
validate() {
    (( $# )) || { echo 'Specify variant numbers 0..6.' >&2; return 2; }
    for stage in "$@"; do
        [[ $stage =~ ^[0-6]$ ]] || { echo "Unknown variant: $stage" >&2; return 2; }
    done
}
preview() {
    validate "$@" || return
    # Resolve exactly the same paths/environment as the actual launcher.
    source "$DEMO_ROOT/demo/env.sh" || return
    printf '\nEnvironment setup:\n  source %q .\n' "$CANN_SETENV"
    printf '  export CANNSIM_COLLECT=%q\n' "$CANNSIM_COLLECT"
    printf "  export BIPROF_OPTS='%s'\n" "$BIPROF_OPTS"
    printf '  export PYTHONPATH=%q\n' "$PYTHONPATH"
    for stage in "$@"; do
        printf '\n[%s — %s] %s\n' "$stage" "${names[$stage]}" "${descriptions[$stage]}"
        printf '  '
        printf '%q ' python3 -m npusim.main record \
            "$BUILD_DIR/Samples/2_Performance/rms_norm_quant_story/rms_norm_quant_${stage}_${names[$stage]}" \
            -s Ascend950 -g vf -n "${REPORT_CORES:-all}" -o "$RESULTS_DIR/rms_norm_quant_${stage}_${names[$stage]}"
        printf '\n'
    done
    printf '\n'
}
run_variants() {
    validate "$@" || return
    preview "$@" || return
    local stage missing=0
    for stage in "$@"; do
        [[ -x "$BUILD_DIR/Samples/2_Performance/rms_norm_quant_story/rms_norm_quant_${stage}_${names[$stage]}" ]] || missing=1
    done
    # Rebuild automatically after relocation, or if this is the first run.
    if (( missing )) || ! python3 "$DEMO_ROOT/demo/check_build_path.py" "$BUILD_DIR" "$DEMO_ROOT/demo"; then
        printf 'Build required. Command: bash %q build\n' "$DEMO_ROOT/start.sh"
        bash "$DEMO_ROOT/start.sh" build || return
    fi
    printf 'Running selected variants: %s\n' "$*"
    bash "$DEMO_ROOT/start.sh" run "$@"
}
case "${1:-}" in
    --list) list_variants; exit 0 ;;
    --dry-run) shift; preview "$@"; exit $? ;;
    --help|-h)
        echo 'bash demo.sh                  — interactive menu'
        echo 'bash demo.sh 2 4 5            — run selected variants'
        echo 'bash demo.sh --dry-run 2 4 5  — show commands without simulation'
        echo 'bash demo.sh --list           — list variants'
        exit 0 ;;
    '') ;;
    *) run_variants "$@"; exit $? ;;
esac
while true; do
    list_variants
    printf '\nEnter variant numbers separated by spaces (example: 2 4 5).\n'
    printf '  a — 1 2 4 5 6; b — build; p 2 4 — preview commands; s — summary; q — quit\n> '
    IFS= read -r selection || break
    read -r -a choices <<< "$selection"
    (( ${#choices[@]} )) || continue
    case "${choices[0]}" in
        q|quit|exit) break ;;
        a) run_variants 1 2 4 5 6 || printf '\nRun failed. See the log above.\n' ;;
        b) printf 'Command: bash %q build\n' "$DEMO_ROOT/start.sh"; bash "$DEMO_ROOT/start.sh" build || true ;;
        p) preview "${choices[@]:1}" || true ;;
        s) printf 'Command: python3 %q\n' "$DEMO_ROOT/demo/summarize.py"; python3 "$DEMO_ROOT/demo/summarize.py" || true ;;
        *) run_variants "${choices[@]}" || printf '\nRun failed. See the log above.\n' ;;
    esac
done
