# NPUSim Prof Live Demo — offline package

Download, transfer, checksum verification, and extraction: [DOWNLOAD.md](DOWNLOAD.md).

The target machine needs Linux x86_64, the same CANN 9.3.0 installation with
Ascend950 support, Python 3.9–3.12 with pip, CMake, make, and cc.
The package includes both source repositories and the offline NumPy wheels.

```bash
cd /new/path/NPUSim_Prof_Live_Demo
export CANN_SETENV=/actual/path/to/cann/bin/setenv.bash
bash demo.sh
```

Enter variant numbers separated by spaces, for example `2 4 5`.
The launcher displays the environment setup and exact commands before execution.
It builds the samples offline when necessary. Menu commands:

- `p 2 4`: show commands without running the simulation.
- `a`: run the main sequence, 1 → 2 → 4 → 5 → 6.
- `b`: build all seven variants.
- `s`: summarize saved profiles.
- `q`: exit.

Run selected variants without the menu: `bash demo.sh 2 4 5`.
Preview commands: `bash demo.sh --dry-run 2 4 5`.
Build and run the complete main sequence: `bash start.sh`.

The default shape is **128 × 256**, with 1024 times fewer elements than the original.
The first run compiles the samples; later runs reuse the build.

Build only: `bash start.sh build`.
Run one variant: `bash start.sh run 4`.
Run the five main variants without rebuilding: `bash start.sh run`.
Additional variants: `bash start.sh run 0 3`.

After relocation, the launcher detects a CMake cache containing old paths,
preserves the old build with a `.previous.*` suffix, and rebuilds at the new location.

Variants 1, 2, 4, 5, and 6 passed their numerical checks. Recorded profiles are included.
The main sequence with reports took about 8 minutes 18 seconds on this machine.
Variant 3 was also recorded for an isolated double-buffer comparison.

[DEMO.md](DEMO.md) contains the presentation order, commands, measurements, hints,
and known profiling limitations. Raw results are in `results/`; console logs are in `logs/`.
Run variants sequentially: executables in the same build directory share input filenames.

Create the transferable archive next to this directory with `bash demo/pack.sh`.
The archive includes sources, wheels, documentation, and recorded results;
build products and Python caches are excluded.

Verify, extract, and run on another machine:

```bash
sha256sum -c NPUSim_Prof_Live_Demo.tar.gz.sha256
tar -xzf NPUSim_Prof_Live_Demo.tar.gz
cd NPUSim_Prof_Live_Demo
export CANN_SETENV=/actual/path/to/cann/bin/setenv.bash
bash demo.sh
```
